import os
import time

folder = "monitored_folder"

# Create test files
for i in range(30):
    with open(os.path.join(folder, f"file_{i}.txt"), "w") as f:
        f.write("Test file for ransomware simulation.\n")

time.sleep(2)  # Short delay before "attack"

# Simulate ransomware: rename all files
for filename in os.listdir(folder):
    old_path = os.path.join(folder, filename)
    new_path = os.path.join(folder, filename + ".locked")
    os.rename(old_path, new_path)
