from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import time, os

# ===== SETTINGS =====
MONITOR_PATH = "monitored_folder"
THRESHOLD = 20
CHANGE_LOG = []
LOG_FILE = "logs/alert.log"
# ====================

class RansomwareDetector(FileSystemEventHandler):
    def on_modified(self, event):
        now = time.time()
        CHANGE_LOG.append(now)

        while CHANGE_LOG and now - CHANGE_LOG[0] > 10:
            CHANGE_LOG.pop(0)

        if len(CHANGE_LOG) > THRESHOLD:
            alert_message = f"[ALERT] Possible ransomware activity detected at {time.ctime()}"
            print(alert_message)
            with open(LOG_FILE, "a") as f:
                f.write(alert_message + "\n")
            CHANGE_LOG.clear()

if __name__ == "__main__":
    if not os.path.exists(MONITOR_PATH):
        print(f"Error: Folder '{MONITOR_PATH}' not found!")
        exit(1)

    event_handler = RansomwareDetector()
    observer = Observer()
    observer.schedule(event_handler, MONITOR_PATH, recursive=True)
    observer.start()
    print(f"Monitoring '{MONITOR_PATH}' for ransomware behavior... Press Ctrl+C to stop.")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
